touch "test.txt"
echo "Hello World" > test.txt
ln test.txt linkedtest.txt
