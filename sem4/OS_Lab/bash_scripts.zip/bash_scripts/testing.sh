#!/bin/bash

echo "hi"

for((int i = 0; i < 5; i++))
echo "hi"
