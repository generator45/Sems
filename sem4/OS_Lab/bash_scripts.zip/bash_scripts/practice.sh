#!/bin/bash

echo "hi"
age=29

if [ $age -lt 30 ] 
then echo "naah fam"
else echo "yaah fam"
fi

