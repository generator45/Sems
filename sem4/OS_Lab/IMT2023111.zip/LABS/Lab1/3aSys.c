#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

int main()
{
    const char *fifo_path = "my1fifo";

    if (mkfifo(fifo_path, 0666) == -1)
    {
        printf("mkfifo failed");
        return 1;
    }

    printf("FIFO named pipe created using mkfifo().\n");
    return 0;
}