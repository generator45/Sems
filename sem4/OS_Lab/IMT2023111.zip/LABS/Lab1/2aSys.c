#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define FILE_ERROR 1
#define SUCCESS 0

int hard_link(FILE *fp)
{
    if (fp == NULL)
    {
        return FILE_ERROR;
    }
    fwrite("Hello World", 1, 11, fp);
    if (link("test.txt", "linkedtest.txt") != 0)
    {
        return FILE_ERROR;
    }
    return SUCCESS;
}

int main()
{
    FILE *fp;
    fp = fopen("test.txt", "w");
    printf("STATUS: %d\n", hard_link(fp));
    fclose(fp);
    fp = NULL;
    return 0;
}