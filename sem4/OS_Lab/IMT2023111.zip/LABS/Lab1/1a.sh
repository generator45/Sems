touch "test.txt"
echo "Hello World" > test.txt
ln -s test.txt linkedtest.txt
